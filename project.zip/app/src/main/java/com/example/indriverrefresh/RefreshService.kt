package com.example.indriverrefresh

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import kotlin.math.abs
import kotlin.random.Random

class RefreshService : AccessibilityService() {

    companion object {
        const val INDRIVE = "sinet.startup.inDriver"
        const val TICK_MS = 250L
        val PRICE_NODE = Regex("^PKR[\\s\\u00A0]*[\\d,.]+$")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var floating: TextView? = null

    private var nextRefreshAt = 0L
    private var lastCardTap = 0L
    private var lastSheetAction = 0L

    private val loop = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Settings.init(this)
        showFloating()
        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 2000)
    }

    // ---------- main logic ----------

    private fun tick() {
        if (!Settings.enabled) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INDRIVE) return

        val texts = mutableListOf<String>()
        collectTexts(root, texts)
        Orders.lastScan = texts.joinToString("\n")
        val now = SystemClock.elapsedRealtime()

        // Screen 2: ride request popup ("Accept for PKRxxx")
        val acceptKeys = Settings.list(Settings.bidTexts)
        val acceptNodes = mutableListOf<AccessibilityNodeInfo>()
        findAll(root, { t -> acceptKeys.any { t.startsWith(it, ignoreCase = true) } }, acceptNodes)
        if (acceptNodes.isNotEmpty()) {
            handleSheet(root, texts, acceptNodes.first(), now)
            return
        }

        // Screen 1: Ride requests list
        val pageKeys = Settings.list(Settings.ridePageTexts)
        val onList = pageKeys.any { key -> texts.any { it.equals(key, ignoreCase = true) } }
        if (!onList) return

        val cards = scanCards(root)
        cards.forEach { Orders.add(it.text.replace("\n", " | ")) }

        // auto-accept ON: sabse high price wala valid card kholo
        if (Settings.autoBid && now - lastCardTap > 2500) {
            val best = cards.filter { !it.skip }.maxByOrNull { it.price }
            if (best != null && click(best.card)) {
                lastCardTap = now
                return
            }
        }

        // refresh
        if (now >= nextRefreshAt) {
            swipeDown()
            val base = Settings.delayMs.toLong()
            nextRefreshAt = now + (base * Random.nextDouble(0.9, 1.15)).toLong()
        }
    }

    private fun handleSheet(
        root: AccessibilityNodeInfo,
        texts: List<String>,
        acceptBtn: AccessibilityNodeInfo,
        now: Long
    ) {
        if (!Settings.autoBid) return
        if (now - lastSheetAction < 1500) return

        val sheetText = texts.joinToString("\n")
        val btnText = (acceptBtn.text ?: acceptBtn.contentDescription)?.toString() ?: ""
        val price = digits(btnText)

        val blocked = Settings.list(Settings.blocked).any { sheetText.contains(it, ignoreCase = true) }
        val tooLow = Settings.minPrice > 0 && price < Settings.minPrice

        lastSheetAction = now
        if (blocked || tooLow) {
            val close = mutableListOf<AccessibilityNodeInfo>()
            findAll(root, { it.equals("Close", ignoreCase = true) }, close)
            close.firstOrNull()?.let { click(it) }
        } else {
            click(acceptBtn)
        }
    }

    private class Card(
        val card: AccessibilityNodeInfo,
        val text: String,
        val price: Long,
        val skip: Boolean
    )

    private fun scanCards(root: AccessibilityNodeInfo): List<Card> {
        val priceNodes = mutableListOf<AccessibilityNodeInfo>()
        findAll(root, { PRICE_NODE.matches(it.trim()) }, priceNodes)
        val blocked = Settings.list(Settings.blocked)

        return priceNodes.map { p ->
            val card = cardOf(p)
            val parts = mutableListOf<String>()
            collectTexts(card, parts)
            val text = parts.joinToString("\n")
            val price = digits((p.text ?: p.contentDescription)?.toString() ?: "")
            val isBlocked = blocked.any { text.contains(it, ignoreCase = true) }
            val tooLow = Settings.minPrice > 0 && price < Settings.minPrice
            Card(card, text, price, isBlocked || tooLow)
        }
    }

    private fun cardOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var t: AccessibilityNodeInfo? = n
        while (t != null && !t.isClickable) t = t.parent
        return t ?: n
    }

    private fun digits(s: String): Long = s.filter { it.isDigit() }.toLongOrNull() ?: 0L

    private fun findAll(
        n: AccessibilityNodeInfo?,
        match: (String) -> Boolean,
        out: MutableList<AccessibilityNodeInfo>
    ) {
        if (n == null) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if (t != null && match(t)) out.add(n)
        for (i in 0 until n.childCount) findAll(n.getChild(i), match, out)
    }

    private fun collectTexts(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null) return
        (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) collectTexts(n.getChild(i), out)
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var t: AccessibilityNodeInfo? = node
        while (t != null && !t.isClickable) t = t.parent
        return t?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun swipeDown() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, dm.heightPixels * 0.35f)
            lineTo(x, dm.heightPixels * 0.75f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 150))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // ---------- floating on/off button ----------

    private fun showFloating() {
        if (floating != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        paint(tv)

        val lp = WindowManager.LayoutParams(
            150, 150,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 400
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        Settings.enabled = !Settings.enabled
                        paint(tv)
                    }
                }
            }
            true
        }

        wm.addView(tv, lp)
        floating = tv
    }

    private fun paint(tv: TextView) {
        val on = Settings.enabled
        tv.text = if (on) "ON" else "OFF"
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        floating?.let { paint(it) }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        floating?.let {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
        }
        floating = null
        super.onDestroy()
    }
}
