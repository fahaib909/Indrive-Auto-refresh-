package com.example.indriverrefresh

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

object Settings {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        }
    }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    var delayMs: Int
        get() = sp.getInt("delayMs", 3000)
        set(v) = sp.edit().putInt("delayMs", v).apply()

    var autoBid: Boolean
        get() = sp.getBoolean("autoBid", false)
        set(v) = sp.edit().putBoolean("autoBid", v).apply()

    var minPrice: Int
        get() = sp.getInt("minPrice", 0)
        set(v) = sp.edit().putInt("minPrice", v).apply()

    var blocked: String
        get() = sp.getString("blocked", "") ?: ""
        set(v) = sp.edit().putString("blocked", v).apply()

    var ridePageTexts: String
        get() = sp.getString("ridePageTexts", "Ride requests") ?: ""
        set(v) = sp.edit().putString("ridePageTexts", v).apply()

    var bidTexts: String
        get() = sp.getString("bidTexts", "Accept for") ?: ""
        set(v) = sp.edit().putString("bidTexts", v).apply()

    fun list(s: String): List<String> =
        s.split(",").map { it.trim() }.filter { it.isNotEmpty() }
}

object Orders {
    private val recent = ArrayDeque<String>()
    @Volatile var lastScan: String = ""

    fun add(text: String) {
        synchronized(this) {
            if (recent.contains(text)) return
            recent.addFirst(text)
            while (recent.size > 50) recent.removeLast()
        }
    }

    fun snapshot(): List<String> = synchronized(this) { recent.toList() }
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 64)
        }

        fun label(t: String): TextView = TextView(this).apply {
            text = t
            setPadding(0, 32, 0, 8)
        }

        fun edit(value: String, number: Boolean, onChange: (String) -> Unit): EditText =
            EditText(this).apply {
                setText(value)
                if (number) inputType = InputType.TYPE_CLASS_NUMBER
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {
                        onChange(s.toString())
                    }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }

        col.addView(Button(this).apply {
            text = "Accessibility Settings kholo"
            setOnClickListener {
                startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        col.addView(Switch(this).apply {
            text = "Auto Refresh ON"
            isChecked = Settings.enabled
            setOnCheckedChangeListener { _, c -> Settings.enabled = c }
        })

        val delayLabel = label("Refresh delay: ${Settings.delayMs / 1000.0} sec")
        col.addView(delayLabel)
        col.addView(SeekBar(this).apply {
            max = 95
            progress = (Settings.delayMs - 500) / 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val ms = 500 + p * 100
                    Settings.delayMs = ms
                    delayLabel.text = "Refresh delay: ${ms / 1000.0} sec"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        col.addView(Switch(this).apply {
            text = "Auto-accept ON"
            isChecked = Settings.autoBid
            setPadding(0, 32, 0, 0)
            setOnCheckedChangeListener { _, c -> Settings.autoBid = c }
        })

        col.addView(label("Minimum price (0 = filter off)"))
        col.addView(edit(Settings.minPrice.toString(), true) {
            Settings.minPrice = it.toIntOrNull() ?: 0
        })

        col.addView(label("Skip words (comma se alag, jaise: airport, delivery)"))
        col.addView(edit(Settings.blocked, false) { Settings.blocked = it })

        col.addView(label("Ride page texts (comma se alag)"))
        col.addView(edit(Settings.ridePageTexts, false) { Settings.ridePageTexts = it })

        col.addView(label("Accept button texts (comma se alag)"))
        col.addView(edit(Settings.bidTexts, false) { Settings.bidTexts = it })

        col.addView(Button(this).apply {
            text = "Orders / Screen scan"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, OrdersActivity::class.java))
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}

class OrdersActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 64)
        }
        val orders = TextView(this)
        val scan = TextView(this)

        fun refresh() {
            val list = Orders.snapshot()
            orders.text = "ORDERS (${list.size})\n\n" +
                    (if (list.isEmpty()) "Abhi koi order nahi mila." else list.joinToString("\n\n"))
            scan.text = "\n\nLAST SCREEN SCAN\n\n" +
                    Orders.lastScan.ifEmpty {
                        "Khali. Switch ON karo, inDrive ride page kholo, phir Scan now dabao."
                    }
        }

        col.addView(Button(this).apply {
            text = "Scan now"
            setOnClickListener { refresh() }
        })
        col.addView(orders)
        col.addView(scan)
        refresh()

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
